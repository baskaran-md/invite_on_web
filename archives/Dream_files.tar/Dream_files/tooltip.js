jQuery(document).ready(function() {
	"use strict";
    /*
        Tooltips
    */
    jQuery('.footer a.facebook').tooltip();
    jQuery('.footer a.twitter').tooltip();
    jQuery('.footer a.skype').tooltip();
    jQuery('.footer a.pinterest').tooltip();
    jQuery('.footer a.icq').tooltip();
    jQuery('.footer a.dropbox').tooltip();
    jQuery('.footer a.soundcloud').tooltip();
    jQuery('.footer a.instagram').tooltip();
    jQuery('.footer a.gplus').tooltip();
    jQuery('#block-3 .circle').tooltip();
   
});


